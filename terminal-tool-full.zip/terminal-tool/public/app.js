const output = document.getElementById("output");
const form = document.getElementById("form");
const input = document.getElementById("command");
const cwdLabel = document.getElementById("cwdLabel");
const promptPath = document.getElementById("promptPath");
const clearBtn = document.getElementById("clearBtn");

let cwd = "/";
let history = [];
let historyIndex = -1;

function print(text, cls = "") {
  const el = document.createElement("div");
  el.className = `line ${cls}`;
  el.textContent = text;
  output.appendChild(el);
  output.scrollTop = output.scrollHeight;
}

function updatePrompt() {
  cwdLabel.textContent = cwd;
  promptPath.textContent = `user@terminal:${cwd} $`;
}

function boot() {
  print("Secure Terminal Tool", "cmd");
  print("Restricted Node.js API • workspace sandbox");
  print('Type "help" to see available commands.', "muted");
  print("");
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const command = input.value.trim();
  if (!command) return;

  history.push(command);
  historyIndex = history.length;
  print(`${promptPath.textContent} ${command}`, "cmd");
  input.value = "";

  try {
    const res = await fetch("/api/terminal", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ command, cwd })
    });
    const data = await res.json();

    if (data.output === "\u0000CLEAR") {
      output.innerHTML = "";
    } else if (data.output) {
      print(data.output, data.ok ? "" : "err");
    }
    if (data.cwd) cwd = data.cwd;
    updatePrompt();
  } catch (err) {
    print("Network error: API unavailable.", "err");
  }
});

input.addEventListener("keydown", (e) => {
  if (e.key === "ArrowUp") {
    e.preventDefault();
    if (historyIndex > 0) historyIndex--;
    input.value = history[historyIndex] || "";
  }
  if (e.key === "ArrowDown") {
    e.preventDefault();
    if (historyIndex < history.length - 1) {
      historyIndex++;
      input.value = history[historyIndex];
    } else {
      historyIndex = history.length;
      input.value = "";
    }
  }
});

clearBtn.addEventListener("click", () => {
  output.innerHTML = "";
  input.focus();
});

document.querySelector(".terminal").addEventListener("click", () => input.focus());

updatePrompt();
boot();